/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package editor;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SplitMenuButton;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Rogiave
 */




public class FXMLController implements Initializable {

    int fontik = 0;
    int fontr = 72;
    String fonta = "Times New Roman";
    boolean english = true;
    
    
    
    
    
    @FXML
    private Menu save;
    
    @FXML
    private Menu Importer;
    
    @FXML
    private SplitMenuButton font;
    
    @FXML
    private ColorPicker colorpicker;
    
    
    @FXML
    private TextArea pole;

    @FXML
    private SplitMenuButton velikost;
    @FXML
    private Label velikostpisma;
    @FXML
    private Label pismo;
    @FXML
    private MenuItem importitem;
    @FXML
    private MenuItem saveitem;
    @FXML
    private MenuItem englishitem;
    @FXML
    private MenuItem czech;
    @FXML
    private Menu helpitem;
    @FXML
    private MenuItem helpitem2;
    @FXML 
    private Menu language;
    @FXML
    private BorderPane okno;
    @FXML
    private MenuItem import_nastavení;
    @FXML
    private Menu import_set;
    
    
    @FXML
    void Times(ActionEvent event) throws IOException{
        pole.setFont(Font.font("Times New Roman",fontr));
        fonta = "Times New Roman";
        String font_txt = "font.txt";
        try (FileWriter filewrite = new FileWriter(font_txt)) {
            filewrite.write("Times New Roman");
            filewrite.flush();
        }
    }
    @FXML
    void Comic(ActionEvent event) throws IOException{
        pole.setFont(Font.font("Comic Sans",fontr));
        fonta = "Comic Sans";
        String font_txt = "font.txt";
        try (FileWriter filewrite = new FileWriter(font_txt)) {
            filewrite.write("Comic Sans");
            filewrite.flush();
        }
    }
    @FXML
    void Calibri(ActionEvent event) throws IOException{
        pole.setFont(Font.font("Calibri",fontr));
        fonta = "Calibri";
        String font_txt = "font.txt";
        try (FileWriter filewrite = new FileWriter(font_txt)) {
            filewrite.write("Calibri");
            filewrite.flush();
        }
    }
    @FXML
    void Verdana(ActionEvent event) throws IOException{
        pole.setFont(Font.font("Verdana",fontr));
        fonta = "Verdana";
        String font_txt = "font.txt";
        try (FileWriter filewrite = new FileWriter(font_txt)) {
            filewrite.write("Verdana");
            filewrite.flush();
        }
        
        
    }
    @FXML
    void Arial(ActionEvent event) throws IOException{
        pole.setFont(Font.font("Arial",fontr));
        fonta = "Arial";
        String font_txt = "font.txt";
        try (FileWriter filewrite = new FileWriter(font_txt)) {
            filewrite.write("Arial");
            filewrite.flush();
        }
    }
    @FXML
    void Futura(ActionEvent event) throws IOException{
        pole.setFont(Font.font("Futura",fontr));
        fonta = "Futura";
        String font_txt = "font.txt";
        try (FileWriter filewrite = new FileWriter(font_txt)) {
            filewrite.write("Futura");
            filewrite.flush();
        }
    }
    @FXML
    void Georgia(ActionEvent event) throws IOException{
        pole.setFont(Font.font("Georgia",fontr));
        fonta = "Georgia";
        String font_txt = "font.txt";
        try (FileWriter filewrite = new FileWriter(font_txt)) {
            filewrite.write("Georgia");
            filewrite.flush();
        }
    }
    @FXML
    void vyberbarvy(ActionEvent event) throws IOException{
        Color colorka=colorpicker.getValue();
        String hexcolor = "#" + Integer.toHexString(colorpicker.getValue().hashCode());
        pole.setStyle("-fx-text-fill:"+hexcolor+";"); 
        
        String color_txt = "color.txt";
        try (FileWriter filewrite = new FileWriter(color_txt)) {
            filewrite.write(hexcolor);
            filewrite.flush();
        }
    }
    @FXML
    void font8(ActionEvent event) throws IOException{
        pole.setFont(Font.font(fonta,8));
        fontr = 8;
        String size_text = "size.txt";
        try (FileWriter filewrite = new FileWriter(size_text)) {
            filewrite.write("8");
            filewrite.flush();
        }
        
        }
            
    @FXML
    void font10(ActionEvent event) throws IOException{
        pole.setFont(Font.font(fonta,10));
        fontr = 10;
        String size_text = "size.txt";
        try (FileWriter filewrite = new FileWriter(size_text)) {
            filewrite.write("10");
            filewrite.flush();
        }
    }
    @FXML
    void font12(ActionEvent event) throws IOException{
        pole.setFont(Font.font(fonta,12));
        fontr = 12;
        String size_text = "size.txt";
        try (FileWriter filewrite = new FileWriter(size_text)) {
            filewrite.write("12");
            filewrite.flush();
        }
    }
    @FXML
    void font14(ActionEvent event) throws IOException{
        pole.setFont(Font.font(fonta,14));
        fontr = 14;
        String size_text = "size.txt";
        try (FileWriter filewrite = new FileWriter(size_text)) {
            filewrite.write("14");
            filewrite.flush();
        }
    }
    @FXML
    void font16(ActionEvent event) throws IOException{
        pole.setFont(Font.font(fonta,16));
        fontr = 16;
        String size_text = "size.txt";
        try (FileWriter filewrite = new FileWriter(size_text)) {
            filewrite.write("16");
            filewrite.flush();
        }
    }
    @FXML
    void font18(ActionEvent event) throws IOException{
        pole.setFont(Font.font(fonta,18));
        fontr = 18;
        String size_text = "size.txt";
        try (FileWriter filewrite = new FileWriter(size_text)) {
            filewrite.write("18");
            filewrite.flush();
        }
    }
    @FXML
    void font20(ActionEvent event) throws IOException{
        pole.setFont(Font.font(fonta,20));
        fontr = 20;
        String size_text = "size.txt";
        try (FileWriter filewrite = new FileWriter(size_text)) {
            filewrite.write("20");
            filewrite.flush();
        }
    }
    @FXML
    void font22(ActionEvent event) throws IOException{
        pole.setFont(Font.font(fonta,22));
        fontr = 22;
        String size_text = "size.txt";
        try (FileWriter filewrite = new FileWriter(size_text)) {
            filewrite.write("22");
            filewrite.flush();
        }
    }
    @FXML
    void font24(ActionEvent event) throws IOException{
        pole.setFont(Font.font(fonta,24));
        fontr = 24;
        String size_text = "size.txt";
        try (FileWriter filewrite = new FileWriter(size_text)) {
            filewrite.write("24");
            filewrite.flush();
        }
    }
    @FXML
    void font28(ActionEvent event) throws IOException{
        pole.setFont(Font.font(fonta,28));
        fontr = 28;
        String size_text = "size.txt";
        try (FileWriter filewrite = new FileWriter(size_text)) {
            filewrite.write("28");
            filewrite.flush();
        }
    }
    @FXML
    void font36(ActionEvent event) throws IOException{
        pole.setFont(Font.font(fonta,36));
        fontr = 36;
        String size_text = "size.txt";
        try (FileWriter filewrite = new FileWriter(size_text)) {
            filewrite.write("36");
            filewrite.flush();
        }
    }
    @FXML
    void font48(ActionEvent event) throws IOException{
        pole.setFont(Font.font(fonta,48));
        fontr = 48;
        String size_text = "size.txt";
        try (FileWriter filewrite = new FileWriter(size_text)) {
            filewrite.write("48");
            filewrite.flush();
        }
    }
    
    @FXML
    void font72(ActionEvent event) throws IOException{
        pole.setFont(Font.font(fonta,72));
        fontr = 72;
        String size_text = "size.txt";
        try (FileWriter filewrite = new FileWriter(size_text)) {
            filewrite.write("72");
            filewrite.flush();
        }
    }
        
    @FXML
    void help(ActionEvent event) {
        if(english == true){
        try{
        Parent root1 = FXMLLoader.load(getClass().getResource("englishhelp.fxml"));
        
        Stage stage1 = new Stage();
        stage1.setScene(new Scene(root1));
        stage1.setTitle("help");
        stage1.show();
        
        }
        catch(IOException e){
            System.err.println(e.getMessage());
            
        }
    }
        else{
        try{
        Parent root2 = FXMLLoader.load(getClass().getResource("czechhelp.fxml"));
        
        Stage stage2 = new Stage();
        stage2.setScene(new Scene(root2));
        stage2.setTitle("Nápověda");
        stage2.show();
        
        }
        catch(IOException e){
            System.err.println(e.getMessage());    
        }
    }
    } 
    @FXML
    void englishchanger(ActionEvent event) throws IOException{
        english = true;
        pismo.setText("Font");
        velikostpisma.setText("Size");
        save.setText("Save");
        saveitem.setText("Save");
        Importer.setText("Import");
        importitem.setText("Import");
        language.setText("Langugage");
        czech.setText("Czech");
        englishitem.setText("English");
        helpitem.setText("Help");
        helpitem2.setText("Help");
        import_nastavení.setText("Previous Settings");
        import_set.setText("Previous Settings");
        
        String size_text_en = "language.txt";
        try (FileWriter filewrite = new FileWriter(size_text_en)) {
            filewrite.write("EN");
            filewrite.flush();
        }
        
        
    }
    @FXML
    void czechchanger(ActionEvent event) throws IOException{
        english = false;
        pismo.setText("Písmo");
        velikostpisma.setText("Velikost");
        save.setText("Uložit");
        saveitem.setText("Uložit");
        Importer.setText("Otevřít");
        importitem.setText("Otevřít");
        language.setText("Jazyk");
        czech.setText("Čeština");
        englishitem.setText("Angličtina");
        helpitem.setText("Nápověda");
        helpitem2.setText("Nápověda");
        import_nastavení.setText("Předchozí nastavení");
        import_set.setText("Předchozí nastavení");
        
        String size_text_en = "language.txt";
        try (FileWriter filewrite = new FileWriter(size_text_en)) {
            filewrite.write("CZ");
            filewrite.flush();
        }
        
    }
    @FXML
    void opener(ActionEvent event){
        try{  
        FileChooser filechooser = new FileChooser();
        filechooser.setTitle("Open");
        
        
        filechooser.getExtensionFilters().addAll(new ExtensionFilter(".TXT","*.txt"));
        File selectedfile = filechooser.showOpenDialog(null);
        
        
        Scanner sc = new Scanner(selectedfile);
        
        sc.useDelimiter("\\Z");
        
        //System.out.println(sc.next());
        //pole.setText("ahoj");
        String text_pole = sc.next();
        //System.out.println(text_pole.getClass());
        //pole.setText("ahoj");
        //System.out.println(text_pole);
        pole.setText(text_pole);
        
        //System.out.println(Paths.get(selectedfile));
        if(selectedfile != null){
            //String datafile = new String(Files.readAllBytes(selectedfile)); 
            //String text = pole.setText();
            //FileWriter fileWriter;
            //fileWriter = new FileWriter(selectedfile);
            //fileWriter.write(text);
            //fileWriter.close();
        }
        /*FileReader fileReader;
        fileReader = new FileWriter(selectedfile);
        fileWriter.write(text);
        fileWriter.close();*/
        
        }
        catch(Exception ex){
            
        }
        
    }
    @FXML
    void saver(ActionEvent event) throws IOException{
        try{
            
        FileChooser filechooser = new FileChooser();
        filechooser.setTitle("Save");
        
        
        filechooser.getExtensionFilters().addAll(new ExtensionFilter(".TXT","*.txt"));
        File selectedfile = filechooser.showSaveDialog(null);
        
        if(selectedfile != null){
            String text = pole.getText();
            FileWriter fileWriter;
            fileWriter = new FileWriter(selectedfile);
            fileWriter.write(text);
            fileWriter.close();
        }
        }
        
        
       
        
        catch(IOException ex){
            
        }}
    @FXML
    void begin(ActionEvent event) throws FileNotFoundException, IOException{
        //nastavení po zavření dokumetu z minula
        //získání textu ze souboru z souboru
        String data_font = new String(Files.readAllBytes(Paths.get("font.txt"))); 
        String data_color = new String(Files.readAllBytes(Paths.get("color.txt"))); 
        String data_language = new String(Files.readAllBytes(Paths.get("language.txt"))); 
        String data_size = new String(Files.readAllBytes(Paths.get("size.txt"))); 
        
        int data_transformed_size = Integer.parseInt(data_size);
        
        //nastavení věcí do pole
        pole.setFont(Font.font(data_font,data_transformed_size));
        pole.setStyle("-fx-text-fill:"+data_color+";");
        
        System.out.println("Došlo to sem");
        System.out.println(data_language);
        if("EN".equals(data_language)){
            english = true;
            pismo.setText("Font");
            velikostpisma.setText("Size");
            save.setText("Save");
            saveitem.setText("Save");
            Importer.setText("Import");
            importitem.setText("Import");
            language.setText("Langugage");
            czech.setText("Czech");
            englishitem.setText("English");
            helpitem.setText("Help");
            helpitem2.setText("Help");
            import_nastavení.setText("Previous Settings");
            import_set.setText("Previous Settings");
        
            String size_text_en = "language.txt";
            try (FileWriter filewrite = new FileWriter(size_text_en)) {
                filewrite.write("EN");
                filewrite.flush();
            }
            System.out.println("English version");
        }
        else if("CZ".equals(data_language)){
            english = false;
            pismo.setText("Písmo");
            velikostpisma.setText("Velikost");
            save.setText("Uložit");
            saveitem.setText("Uložit");
            Importer.setText("Otevřít");
            importitem.setText("Otevřít");
            language.setText("Jazyk");
            czech.setText("Čeština");
            englishitem.setText("Angličtina");
            helpitem.setText("Nápověda");
            helpitem2.setText("Nápověda");
            import_nastavení.setText("Předchozí nastavení");
            import_set.setText("Předchozí nastavení");
        
            String size_text_en = "language.txt";
            try (FileWriter filewrite = new FileWriter(size_text_en)) {
                filewrite.write("CZ");
                filewrite.flush();
            }
            System.out.println("czech version");
        }
        else{
            System.out.println("nefakčí");
        }
        
        System.out.println(data_font);
        System.out.println(data_color);
        System.out.println(data_language);
        System.out.println(data_size);
        
        
        
    }
        
    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
